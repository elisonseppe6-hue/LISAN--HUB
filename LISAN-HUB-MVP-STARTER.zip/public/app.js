async function loadServices() {
  const list = document.getElementById("service-list");

  try {
    const response = await fetch("/api/services");
    const services = await response.json();

    list.innerHTML = services.map(service => `
      <article class="card">
        <h3>${service.name}</h3>
        <p>${service.description}</p>
        <div class="tokens">${service.tokens} Tokeni</div>
        <button class="use-btn" onclick="useService('${service.name}')">
          Tumia Huduma
        </button>
      </article>
    `).join("");
  } catch (error) {
    list.innerHTML = "<p>Imeshindikana kupakia huduma.</p>";
  }
}

function useService(serviceName) {
  alert(`Umechagua: ${serviceName}. Mfumo wa tokeni utaongezwa kwenye hatua inayofuata.`);
}

loadServices();
